import * as React from 'react';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { PrimaryButton, DefaultButton, IconButton, Button} from 'office-ui-fabric-react/lib/Button';
import { ContextualMenu } from 'office-ui-fabric-react/lib/ContextualMenu';
import { SpinButton } from 'office-ui-fabric-react/lib/SpinButton';
import { Checkbox } from 'office-ui-fabric-react/lib/Checkbox';
import { Icon, FontIcon } from 'office-ui-fabric-react/lib/Icon';
import { ComboBox,IComboBoxProps,IComboBoxOption, SelectableOptionMenuItemType, TextField, getAllSelectedOptions, IconType } from 'office-ui-fabric-react/lib/index';
import { initializeIcons } from '@uifabric/icons';

export interface IDialogBlockingExampleState {
  hideDialog: boolean;
  isDraggable: boolean;
  email: string;
  selectedRecord:number | string;
  options:IComboBoxOption[];
}


initializeIcons();

export class DialogBlockingExample extends React.Component<{}, IDialogBlockingExampleState> {

  public state: IDialogBlockingExampleState = { hideDialog: true, isDraggable: false, email: '',  selectedRecord:'', options:[],
  };

  private _dragOptions = {
    moveMenuItemText: 'Move',
    closeMenuItemText: 'Close',
    menu: ContextualMenu
  };


  public async componentDidMount() {
    if (this.state.options.length > 0) {
        console.log("SR"+ this.state.selectedRecord)

        return this.state.options
    }
   await this._getoptions()
   
};

  public render() {
    const { hideDialog, isDraggable } = this.state;
    console.log(this.state);
    return (
      <div>
     <div>
      {/* <FontIcon iconName="PageHeaderEdit" onClick={this._showDialog}  /> */}
      {/* <Icon iconName="WindowEdit" onClick={this._showDialog} title={"Update Patient"} color="dodgerblue" font-size='32px'/> */}
      <PrimaryButton onClick={this._showDialog} text="Update Patient" color="dodgerblue"  />
      {/* <IconButton iconProps={{ iconName: 'SaveAs' }} title="Update Patient" ariaLabel="Update Patient" /> */}
    </div>
        {/* <DefaultButton secondaryText="Opens the Sample Dialog" onClick={this._showDialog} text="Open Dialog" />  */}
        <Dialog
          hidden={hideDialog}
          onDismiss={this._closeDialog}
          dialogContentProps={{
            type: DialogType.normal,
            title: 'Update Patient',
            // subText: 'Do you want to send this message without a subject?'
          }}
          modalProps={{
            isBlocking: true,
            styles: { main: { maxWidth: 450 } },
            dragOptions: isDraggable ? this._dragOptions : undefined
          }}
        >
         
          {/* <TextField label="Standard" value={this.state.email} onChange={(e: any) => this.setState({ email: e.target.value })}/> */}
          
          <ComboBox
            label="Choose a Payment Option"
            placeholder="Select or type an option"
            allowFreeform
            autoComplete="on"
            options={this.state.options}
            onChange ={this._onChange}
            defaultSelectedKey=
            {this.state.selectedRecord}
          />
          <DialogFooter>
        
            <PrimaryButton onClick={this._updateDialog} text="Update" />
            <DefaultButton onClick={this._closeDialog} text="close" />
            
            
          </DialogFooter>
        </Dialog>
      </div>
    );
  }
 private _getselectedOptions=()=>{
  let _self =this;
  let selectedoption:any;
  let id=  Xrm.Page.getAttribute("cb_patient").getValue()[0].id.replace('{','').replace('}','');
     var req = new XMLHttpRequest();
     req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/cb_patients("+id+")?$select=cb_paidby", false);
     req.setRequestHeader("OData-MaxVersion", "4.0");
     req.setRequestHeader("OData-Version", "4.0");
     req.setRequestHeader("Accept", "application/json");
     req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
     req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
     req.onreadystatechange = function() {
         if (this.readyState === 4) {
             req.onreadystatechange = null;
             if (this.status === 200) {
                 var result = JSON.parse(this.response);
                 selectedoption =result["cb_paidby"]
               
  _self.setState({
    selectedRecord:selectedoption
  }   )    
             } 
             else {
             }
         }
     };
   req.send();
   //alert("showlast"+_self.state.selectedRecord)
  //  _self.setState({
  //   selectedRecord:selectedoption
  //  })
  
 }

  private _getoptions=()=>{
    let _self = this
    let options: IComboBoxOption[] = []
    let id = Xrm.Page.data.entity.getId().replace('{','').replace('}','');
    var req = new XMLHttpRequest();
    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/stringmaps?$select=attributename,attributevalue,value&$filter=attributename eq 'cb_paidby'", true);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function() {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = 0; i < results.value.length; i++) {

                  options.push({
                    key: results.value[i]["attributevalue"],//"recordid"
                    text: results.value[i]["value"] //recordname
                  });
                }

                _self.setState({
                  options
                
                })
            } else {
                //Xrm.Utility.alertDialog(this.statusText);
            }
        }
    };
    req.send();
    
  }


  private _onChange: IComboBoxProps['onChange'] = (event, option) => {
    if (option) {
      this.setState({ selectedRecord: option.key });
      console.log(option.key);
    }
  };




  private _showDialog =  (): void => {
     this._getselectedOptions();
    
    //alert("showlast"+_self.state.selectedRecord)
    this.setState({ hideDialog: false });

   
  };

  private _closeDialog = (): void => {

    this.setState({ hideDialog: true });
    
  };




  private _updateDialog = ():void=> {
            let id=  Xrm.Page.getAttribute("cb_patient").getValue()[0].id.replace('{','').replace('}','');
            var entity = {cb_paidby : this.state.selectedRecord};
          var req = new XMLHttpRequest();
          req.open("PATCH", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/cb_patients("+id+")", true);
          req.setRequestHeader("OData-MaxVersion", "4.0");
          req.setRequestHeader("OData-Version", "4.0");
          req.setRequestHeader("Accept", "application/json");
          req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
          req.setRequestHeader("If-Match", "*");
          req.onreadystatechange = function() {
              if (this.readyState === 4) {
                  req.onreadystatechange = null;
                  if (this.status === 204) {
                      //Success - No Return Data - Do Something
                  } else {
                      //Xrm.Utility.alertDialog(this.statusText);
                  }
              }
          };
          req.send(JSON.stringify(entity));

              this.setState({ hideDialog: true });
              
            };

  // private _toggleDraggable = (): void => {
  //   this.setState({ isDraggable: !this.state.isDraggable });
  // };
}
