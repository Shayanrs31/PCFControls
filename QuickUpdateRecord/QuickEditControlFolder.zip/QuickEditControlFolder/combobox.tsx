import * as React from 'react';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
// import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { ContextualMenu } from 'office-ui-fabric-react/lib/ContextualMenu';
import { SpinButton } from 'office-ui-fabric-react/lib/SpinButton';
import { Checkbox } from 'office-ui-fabric-react/lib/Checkbox';
//import { IComboBox,IComboBoxProps ,IComboBoxOption, TextField, getAllSelectedOptions, IconType } from 'office-ui-fabric-react/lib/index';
import ReactDOM = require('react-dom');


import { ComboBox, Fabric, IComboBox, IComboBoxOption, IComboBoxProps, mergeStyles, PrimaryButton, SelectableOptionMenuItemType, initializeIcons } from 'office-ui-fabric-react/lib/index';

// Initialize icons in case this example uses them
initializeIcons();

const INITIAL_OPTIONS: IComboBoxOption[] = [
  { key: 'Header1', text: 'First heading', itemType: SelectableOptionMenuItemType.Header },
  { key: 'A', text: 'Option A' },
  { key: 'B', text: 'Option B' },
  { key: 'C', text: 'Option C' },
  { key: 'D', text: 'Option D' },
  { key: 'divider', text: '-', itemType: SelectableOptionMenuItemType.Divider },
  { key: 'Header2', text: 'Second heading', itemType: SelectableOptionMenuItemType.Header },
  { key: 'E', text: 'Option E' },
  { key: 'F', text: 'Option F', disabled: true },
  { key: 'G', text: 'Option G' },
  { key: 'H', text: 'Option H' },
  { key: 'I', text: 'Option I' },
  { key: 'J', text: 'Option J' }
];

const wrapperClassName = mergeStyles({
  selectors: {
    '& > *': { marginBottom: '20px' },
    '& .ms-ComboBox': { maxWidth: '300px' }
  }
});

interface IComboBoxBasicExampleState {
  dynamicErrorValue: number | string;
}

// tslint:disable:jsx-no-lambda
export class ComboBoxBasicExample extends React.Component<{}, IComboBoxBasicExampleState> {
  private _basicComboBox = React.createRef<IComboBox>();

  constructor(props: {}) {
    super(props);
    this.state = {
      dynamicErrorValue: ''
    };
  }

  public render(): JSX.Element {
    console.log(this.state)
    return (
      <Fabric className={wrapperClassName}>
        <div>
          {/* This example demonstrates various props, but only `options` is required. */}
          

          
        </div>

        <ComboBox
          multiSelect
          
          label="Multi-select"
          allowFreeform
          autoComplete="on"
          options={INITIAL_OPTIONS}
           onChange={this._onChange}
        />

      </Fabric>
    );
  }

  private _onChange: IComboBoxProps['onChange'] = (event, option) => {
    if (option) {
      this.setState({ dynamicErrorValue: option.key });
      console.log(option.key)
    }
  };

  private _getErrorMessage(value: number | string) {
    if (value === 'B') {
      return 'B is not an allowed option!';
    }
    return '';
  }
}

const ComboBoxBasicExampleWrapper = () => <Fabric><ComboBoxBasicExample /></Fabric>;
ReactDOM.render(<ComboBoxBasicExampleWrapper />, document.getElementById('content'))